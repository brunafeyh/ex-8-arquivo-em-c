/*8. Fac¸a um programa que leia o conteudo de um arquivo e crie um arquivo com o mesmo ´
conteudo, mas com todas as letras min ´ usculas convertidas para mai ´ usculas. Os no- ´
mes dos arquivos serao fornecidos, via teclado, pelo usu ˜ ario. A func¸ ´ ao que converte ˜
maiuscula para min ´ uscula ´ e o toupper(). Ela ´ e aplicada em cada caractere da string.

BRUNA CAROLINA DA SILVA FEYH 
22/08/2023
*/
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <ctype.h>

#define MAX 1000000

void getnovastring(char str[], int n){
    int i;
    for(i=0; i<n; i++){
        if(islower(str[i])){
            str[i] = toupper(str[i]);
        }
    }
}


int parq(char *s, char str[]){
    FILE *f;
    f = fopen(s, "w");
    if(f == NULL) return errno;
    
    fprintf(f, "%s", str);
 
    fclose(f);
    return 0;
}
int lerarq(char *s, char str[]){
    FILE *f;
    f = fopen(s, "r");
    if(f == NULL) return errno;
    
    fscanf(f, "%[^EOF]", str);
 
    fclose(f);
    return 0;
}
int main()
{
    char ch[MAX], a[20], b[20];

    int erro, tam;
    
    printf("Digite o nome do documento de leitura:\n");
    scanf("%s", a);
    printf("Digite o nome do documento de impressão:\n");
    scanf("%s", b);
    
    erro = lerarq(a , ch);
    if(erro != 0) printf("erro de leitura: %d\n", erro);
    
    tam = strlen(ch);
    
    getnovastring(ch, tam);
    
    erro = parq(b, ch);
    if(erro != 0) printf("erro de gravação: %d\n", erro);
    
   
    return 0;
}
